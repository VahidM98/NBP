﻿namespace RegistracijaVozila
{
    partial class OrganizacijaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvOrganizacije = new System.Windows.Forms.DataGridView();
            this.txtNaziv = new MetroFramework.Controls.MetroTextBox();
            this.txtGrad = new MetroFramework.Controls.MetroTextBox();
            this.txtUlica = new MetroFramework.Controls.MetroTextBox();
            this.lbINaziv = new MetroFramework.Controls.MetroLabel();
            this.lblGrad = new MetroFramework.Controls.MetroLabel();
            this.lblUlica = new MetroFramework.Controls.MetroLabel();
            this.cmbRadnici = new System.Windows.Forms.ComboBox();
            this.lblRadnici = new MetroFramework.Controls.MetroLabel();
            this.btnDodaj = new System.Windows.Forms.Button();
            this.btnIzmeni = new System.Windows.Forms.Button();
            this.btnBrisanje = new System.Windows.Forms.Button();
            this.lblBrisanje = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrganizacije)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvOrganizacije
            // 
            this.dgvOrganizacije.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOrganizacije.Location = new System.Drawing.Point(-1, 5);
            this.dgvOrganizacije.Name = "dgvOrganizacije";
            this.dgvOrganizacije.Size = new System.Drawing.Size(801, 216);
            this.dgvOrganizacije.TabIndex = 1;
            // 
            // txtNaziv
            // 
            // 
            // 
            // 
            this.txtNaziv.CustomButton.Image = null;
            this.txtNaziv.CustomButton.Location = new System.Drawing.Point(83, 1);
            this.txtNaziv.CustomButton.Name = "";
            this.txtNaziv.CustomButton.Size = new System.Drawing.Size(19, 19);
            this.txtNaziv.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtNaziv.CustomButton.TabIndex = 1;
            this.txtNaziv.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtNaziv.CustomButton.UseSelectable = true;
            this.txtNaziv.CustomButton.Visible = false;
            this.txtNaziv.Lines = new string[0];
            this.txtNaziv.Location = new System.Drawing.Point(57, 241);
            this.txtNaziv.MaxLength = 32767;
            this.txtNaziv.Name = "txtNaziv";
            this.txtNaziv.PasswordChar = '\0';
            this.txtNaziv.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtNaziv.SelectedText = "";
            this.txtNaziv.SelectionLength = 0;
            this.txtNaziv.SelectionStart = 0;
            this.txtNaziv.ShortcutsEnabled = true;
            this.txtNaziv.Size = new System.Drawing.Size(103, 21);
            this.txtNaziv.TabIndex = 2;
            this.txtNaziv.UseSelectable = true;
            this.txtNaziv.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtNaziv.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtGrad
            // 
            // 
            // 
            // 
            this.txtGrad.CustomButton.Image = null;
            this.txtGrad.CustomButton.Location = new System.Drawing.Point(83, 1);
            this.txtGrad.CustomButton.Name = "";
            this.txtGrad.CustomButton.Size = new System.Drawing.Size(19, 19);
            this.txtGrad.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtGrad.CustomButton.TabIndex = 1;
            this.txtGrad.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtGrad.CustomButton.UseSelectable = true;
            this.txtGrad.CustomButton.Visible = false;
            this.txtGrad.Lines = new string[0];
            this.txtGrad.Location = new System.Drawing.Point(57, 284);
            this.txtGrad.MaxLength = 32767;
            this.txtGrad.Name = "txtGrad";
            this.txtGrad.PasswordChar = '\0';
            this.txtGrad.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtGrad.SelectedText = "";
            this.txtGrad.SelectionLength = 0;
            this.txtGrad.SelectionStart = 0;
            this.txtGrad.ShortcutsEnabled = true;
            this.txtGrad.Size = new System.Drawing.Size(103, 21);
            this.txtGrad.TabIndex = 3;
            this.txtGrad.UseSelectable = true;
            this.txtGrad.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtGrad.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // txtUlica
            // 
            // 
            // 
            // 
            this.txtUlica.CustomButton.Image = null;
            this.txtUlica.CustomButton.Location = new System.Drawing.Point(83, 1);
            this.txtUlica.CustomButton.Name = "";
            this.txtUlica.CustomButton.Size = new System.Drawing.Size(19, 19);
            this.txtUlica.CustomButton.Style = MetroFramework.MetroColorStyle.Blue;
            this.txtUlica.CustomButton.TabIndex = 1;
            this.txtUlica.CustomButton.Theme = MetroFramework.MetroThemeStyle.Light;
            this.txtUlica.CustomButton.UseSelectable = true;
            this.txtUlica.CustomButton.Visible = false;
            this.txtUlica.Lines = new string[0];
            this.txtUlica.Location = new System.Drawing.Point(57, 327);
            this.txtUlica.MaxLength = 32767;
            this.txtUlica.Name = "txtUlica";
            this.txtUlica.PasswordChar = '\0';
            this.txtUlica.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtUlica.SelectedText = "";
            this.txtUlica.SelectionLength = 0;
            this.txtUlica.SelectionStart = 0;
            this.txtUlica.ShortcutsEnabled = true;
            this.txtUlica.Size = new System.Drawing.Size(103, 21);
            this.txtUlica.TabIndex = 4;
            this.txtUlica.UseSelectable = true;
            this.txtUlica.WaterMarkColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            this.txtUlica.WaterMarkFont = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Pixel);
            // 
            // lbINaziv
            // 
            this.lbINaziv.AutoSize = true;
            this.lbINaziv.Location = new System.Drawing.Point(175, 243);
            this.lbINaziv.Name = "lbINaziv";
            this.lbINaziv.Size = new System.Drawing.Size(41, 19);
            this.lbINaziv.TabIndex = 5;
            this.lbINaziv.Text = "Naziv";
            // 
            // lblGrad
            // 
            this.lblGrad.AutoSize = true;
            this.lblGrad.Location = new System.Drawing.Point(175, 286);
            this.lblGrad.Name = "lblGrad";
            this.lblGrad.Size = new System.Drawing.Size(38, 19);
            this.lblGrad.TabIndex = 6;
            this.lblGrad.Text = "Grad";
            // 
            // lblUlica
            // 
            this.lblUlica.AutoSize = true;
            this.lblUlica.Location = new System.Drawing.Point(175, 329);
            this.lblUlica.Name = "lblUlica";
            this.lblUlica.Size = new System.Drawing.Size(37, 19);
            this.lblUlica.TabIndex = 7;
            this.lblUlica.Text = "Ulica";
            // 
            // cmbRadnici
            // 
            this.cmbRadnici.FormattingEnabled = true;
            this.cmbRadnici.Location = new System.Drawing.Point(57, 372);
            this.cmbRadnici.Name = "cmbRadnici";
            this.cmbRadnici.Size = new System.Drawing.Size(103, 21);
            this.cmbRadnici.TabIndex = 9;
            // 
            // lblRadnici
            // 
            this.lblRadnici.AutoSize = true;
            this.lblRadnici.Location = new System.Drawing.Point(175, 374);
            this.lblRadnici.Name = "lblRadnici";
            this.lblRadnici.Size = new System.Drawing.Size(48, 19);
            this.lblRadnici.TabIndex = 10;
            this.lblRadnici.Text = "Radnik";
            // 
            // btnDodaj
            // 
            this.btnDodaj.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnDodaj.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnDodaj.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDodaj.Location = new System.Drawing.Point(303, 297);
            this.btnDodaj.Name = "btnDodaj";
            this.btnDodaj.Size = new System.Drawing.Size(88, 32);
            this.btnDodaj.TabIndex = 11;
            this.btnDodaj.Text = "Dodaj";
            this.btnDodaj.UseVisualStyleBackColor = false;
            // 
            // btnIzmeni
            // 
            this.btnIzmeni.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnIzmeni.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnIzmeni.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIzmeni.Location = new System.Drawing.Point(427, 297);
            this.btnIzmeni.Name = "btnIzmeni";
            this.btnIzmeni.Size = new System.Drawing.Size(88, 32);
            this.btnIzmeni.TabIndex = 12;
            this.btnIzmeni.Text = "Izmeni";
            this.btnIzmeni.UseVisualStyleBackColor = false;
            // 
            // btnBrisanje
            // 
            this.btnBrisanje.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnBrisanje.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBrisanje.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrisanje.Location = new System.Drawing.Point(551, 297);
            this.btnBrisanje.Name = "btnBrisanje";
            this.btnBrisanje.Size = new System.Drawing.Size(88, 32);
            this.btnBrisanje.TabIndex = 13;
            this.btnBrisanje.Text = "Brisanje";
            this.btnBrisanje.UseVisualStyleBackColor = false;
            // 
            // lblBrisanje
            // 
            this.lblBrisanje.AutoSize = true;
            this.lblBrisanje.Location = new System.Drawing.Point(530, 258);
            this.lblBrisanje.Name = "lblBrisanje";
            this.lblBrisanje.Size = new System.Drawing.Size(144, 13);
            this.lblBrisanje.TabIndex = 26;
            this.lblBrisanje.Text = "Organizacija za brisanje (ID): ";
            // 
            // OrganizacijaForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblBrisanje);
            this.Controls.Add(this.btnBrisanje);
            this.Controls.Add(this.btnIzmeni);
            this.Controls.Add(this.btnDodaj);
            this.Controls.Add(this.lblRadnici);
            this.Controls.Add(this.cmbRadnici);
            this.Controls.Add(this.lblUlica);
            this.Controls.Add(this.lblGrad);
            this.Controls.Add(this.lbINaziv);
            this.Controls.Add(this.txtUlica);
            this.Controls.Add(this.txtGrad);
            this.Controls.Add(this.txtNaziv);
            this.Controls.Add(this.dgvOrganizacije);
            this.Name = "OrganizacijaForm";
            this.Text = "OrganizacijaForm";
            this.Load += new System.EventHandler(this.OrganizacijaForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvOrganizacije)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvOrganizacije;
        private MetroFramework.Controls.MetroTextBox txtNaziv;
        private MetroFramework.Controls.MetroTextBox txtGrad;
        private MetroFramework.Controls.MetroTextBox txtUlica;
        private MetroFramework.Controls.MetroLabel lbINaziv;
        private MetroFramework.Controls.MetroLabel lblGrad;
        private MetroFramework.Controls.MetroLabel lblUlica;
        private System.Windows.Forms.ComboBox cmbRadnici;
        private MetroFramework.Controls.MetroLabel lblRadnici;
        private System.Windows.Forms.Button btnDodaj;
        private System.Windows.Forms.Button btnIzmeni;
        private System.Windows.Forms.Button btnBrisanje;
        private System.Windows.Forms.Label lblBrisanje;
    }
}