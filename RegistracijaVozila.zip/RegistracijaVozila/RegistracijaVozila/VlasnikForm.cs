﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RegistracijaVozila
{
    public partial class VlasnikForm : MetroFramework.Forms.MetroForm
    {
        public VlasnikForm()
        {
            InitializeComponent();
        }

        private void VlasnikForm_Load(object sender, EventArgs e)
        {

        }
    }
}
