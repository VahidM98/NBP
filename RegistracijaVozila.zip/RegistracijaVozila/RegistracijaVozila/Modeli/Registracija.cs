﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RegistracijaVozila.Modeli
{
    public class Registracija
    {
        public int RegistracijaId { set; get; }
        public int Cena { set; get; }
        public DateTime Datum { set; get; }
        public Radnik Radnik { set; get; }
        public Vozilo Vozilo { set; get; }
        public int RadnikId { set; get; }
        public int VoziloId { set; get; }
    }
}
