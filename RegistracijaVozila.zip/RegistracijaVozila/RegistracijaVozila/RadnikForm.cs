﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RegistracijaVozila
{
    public partial class RadnikForm : MetroFramework.Forms.MetroForm
    {
        public RadnikForm()
        {
            InitializeComponent();
        }

        private void RadnikForm_Load(object sender, EventArgs e)
        {

        }

        private void metroTextBox1_Click(object sender, EventArgs e)
        {

        }

        private void lbOrganizacija_Click(object sender, EventArgs e)
        {

        }

        private void dgvRadnici_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
